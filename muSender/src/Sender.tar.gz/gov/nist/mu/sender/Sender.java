/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.nist.mu.sender;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;


/**
 * @author mccaffrey
 */
public class Sender {

    public static final int REST = 1;
    public static final int SOAP = 2;

    public static void main(String[] args) {

        String pathToSampleDirectory = "/home/mccaffrey/hitsp/cvsfiles/hitspValidation/mu/samples";

        String hostnameOrIp = "localhost";
        String port = "4444";
        String path = "";
        String sampleString = Sender.fetchFile(pathToSampleDirectory);
        // System.out.println(sampleString);
        
        int protocol = 2;
        switch(protocol) {
            case REST:
                Sender.sendRest(hostnameOrIp,port,path,sampleString);
                break;

            case SOAP:
                Sender.sendSoap(hostnameOrIp,port,path,sampleString);
                break;
        }
    }

    public static void sendRest(String hostname, String port, String path, String message) {

        StringBuffer sb = new StringBuffer();

        sb.append("POST /" + path + " HTTP/1.1\n");
        sb.append("Content-Type: application/soap+xml; charset=utf-8\n");
        sb.append("Content-Length: " + message.length() + '\n');
        sb.append('\n');
        sb.append(message);

        Socket destination = null;
        try {
            destination = new Socket(hostname, Integer.parseInt(port));
            PrintWriter out = new PrintWriter(destination.getOutputStream(), true);
            out.print(sb.toString());
            out.flush();
            out.close();
            destination.close();
        } catch(UnknownHostException ex) {
            // TODO
            ex.printStackTrace();
        } catch(IOException ex) {
            // TODO
            ex.printStackTrace();
        }



    }

    public static void sendSoap(String hostname, String port, String path, String message) {

        StringBuffer sb = new StringBuffer();
        sb.append("<?xml version=\"1.0\"?>\n");
        sb.append("<soap:Envelope ");
        sb.append("xmlns:soap=\"http://www.w3.org/2001/12/soap-envelope\" ");
        sb.append("soap:encodingStyle=\"http://www.w3.org/2001/12/soap-encoding\">\n");
        sb.append("<soap:Body>");
        sb.append(message);
        sb.append("</soap:Body>\n");
        sb.append("</soap:Envelope>");

        Sender.sendRest(hostname, port, path, sb.toString());
    }

    public static String fetchFile(String pathToSampleDirectory) {
        File sampleDirectory = new File(pathToSampleDirectory);
        File[] fileList = sampleDirectory.listFiles();
        int random = (int) (Math.random() * fileList.length);
        File sampleFile = fileList[random];
        String sampleString = null;
        try {
            sampleString = Sender.readFile(sampleFile);
        } catch(FileNotFoundException ex) {
            // TODO
        } catch(IOException ex) {
            // TODO
        }
        return sampleString;
    }

    public static String readFile(File file) throws FileNotFoundException, IOException {
        BufferedReader input = new BufferedReader(new FileReader(file));
        String line = null;
        StringBuilder xml = new StringBuilder();
        while((line = input.readLine()) != null)
            xml.append(line);
        return xml.toString();        
    }
}
